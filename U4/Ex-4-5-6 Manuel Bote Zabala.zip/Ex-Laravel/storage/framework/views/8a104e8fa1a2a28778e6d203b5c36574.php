<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reserva</title>
</head>
<body>

    <h1>Crear Reserva</h1>

    <br><br>
    <?php if(session("mensaje")): ?>
        <div style="color: red"><?php echo e(session("mensaje")); ?></div>
    <?php endif; ?>

    <form action="<?php echo e(route("crearReserva")); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div>
            <label for="viaje">Viaje</label>
            <select name="viaje" id="viaje">
                <?php $__currentLoopData = $viajes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($v->id); ?>"><?php echo e($v->TituloViaje); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div>
            <label for="fecha">Fecha</label>
            <input type="date" name="fecha" id="fecha" value="<?php echo e(date('Y-m-d')); ?>">
        </div>

        <div>
            <label for="nombre">Cliente</label>
            <input type="text" name="nombre" id="nombre">
        </div>

        <div>
            <label for="nPersonas">Nº de Personas</label>
            <input type="number" name="nPersonas" id="nPersonas" value="1">
        </div>

        <button type="submit">Crear</button>
        <button><a href="<?php echo e(route("verViajes")); ?>">Cancelar</a></button>
    </form>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\DWES\U4\Ex-Laravel\resources\views/reservas/reserva.blade.php ENDPATH**/ ?>